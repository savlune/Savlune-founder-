import { readFile, writeFile } from 'node:fs/promises';
import { parseFeed } from '../worker/runtime.mjs';
const edition=JSON.parse(await readFile('src/data/insights.json','utf8'));
let live=null;
try {
 const response=await fetch('https://feeds.bbci.co.uk/news/business/rss.xml',{signal:AbortSignal.timeout(15000)});
 if(!response.ok)throw new Error('RSS unavailable');
 const items=parseFeed(await response.text());
 if(items.length<3)throw new Error('Not enough fresh headlines');
 live={updatedAt:new Date().toISOString(),items};
} catch(error) {
 console.warn('News refresh unavailable; retaining previous edition.');
 try {const old=await fetch('https://savlune.github.io/Savlune-founder-/news.json',{signal:AbortSignal.timeout(10000)});if(old.ok)live=(await old.json()).live??null;}catch{}
}
await writeFile('public/news.json',JSON.stringify({...edition,live,sourceAvailable:!!live}));
await writeFile('public/.nojekyll','');
