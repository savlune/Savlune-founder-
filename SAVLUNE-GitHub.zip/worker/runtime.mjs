// Assets and the initial editorial edition are injected by scripts/build-worker.mjs.
const FEED_URL = 'https://feeds.bbci.co.uk/news/business/rss.xml';
const NEWS_KEY = 'savlune/live-news/business-focus-v2.json';
const CACHE_MS = 15 * 60 * 1000;
const json = (value,status=200) => new Response(JSON.stringify(value), {status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
function plain(value) {
  return value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]*>/g,'').replace(/&#(x[0-9a-f]+|\d+);/gi,(_,v)=>{const n=v[0].toLowerCase()==='x'?parseInt(v.slice(1),16):parseInt(v,10);return n<=0x10ffff?String.fromCodePoint(n):'';}).replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&apos;|&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').trim();
}
export function newsTopic(title) {
  if (/\b(bank ?notes?|dollar|euro|sterling|yen|yuan|rupiah|forex|currenc(?:y|ies)|exchange rates?)\b/i.test(title)) return 'Mata Uang';
  if (/\b(oil|gold|silver|copper|steel|commodit(?:y|ies)|crude|coal|gas|energy|wheat)\b/i.test(title)) return 'Komoditas';
  if (/\b(earnings|profit|revenue|shares?|stocks?|merger|acquisition|ipo|company|companies|microsoft|tesla|amazon|apple|banks?|start-ups?)\b/i.test(title)) return 'Perusahaan';
  if (/\b(business|econom(?:y|ic)|growth|exports?|imports?|tariffs?|trade|budget|inflation|finance|industry|industries|taxes)\b/i.test(title)) return 'Bisnis';
  return null;
}
export function parseFeed(xml, now=Date.now()) {
  const entries=[];
  for(const match of xml.matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/g)) {
    const tag=name=>plain(match[1].match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)<\\/${name}>`,'i'))?.[1]||'');
    const title=tag('title'), url=tag('link'), publishedAt=tag('pubDate');
    const timestamp=Date.parse(publishedAt);
    const category=newsTopic(title);
    if(!category)continue;
    let valid=false;try{const u=new URL(url);valid=u.protocol==='https:'&&['www.bbc.co.uk','www.bbc.com','bbc.co.uk','bbc.com'].includes(u.hostname);}catch{}
    if(!title || !valid || !Number.isFinite(timestamp) || timestamp>now+300000 || now-timestamp>30*86400000)continue;
    if(entries.some(item=>item.url===url))continue;
    entries.push({title:title.slice(0,240),url,publishedAt:new Date(timestamp).toISOString(),source:'BBC News · Business',category});
  }
  const sorted=entries.sort((a,b)=>Date.parse(b.publishedAt)-Date.parse(a.publishedAt));
  const selected=[];
  // Reserve slots for currency and commodity coverage when fresh articles exist.
  for(const category of ['Mata Uang','Komoditas','Perusahaan']) {
    const item=sorted.find(entry=>entry.category===category);
    if(item)selected.push(item);
  }
  for(const item of sorted)if(selected.length<3&&!selected.includes(item))selected.push(item);
  return selected.sort((a,b)=>Date.parse(b.publishedAt)-Date.parse(a.publishedAt));
}
async function readNews(env) { const object=await env.BUCKET.get(NEWS_KEY); return object?await object.json():null; }
async function refreshNews(env) {
  const previous=await readNews(env);
  if(previous && Date.now()-Date.parse(previous.updatedAt)<CACHE_MS) return {...previous,cached:true};
  const response=await fetch(FEED_URL,{headers:{'Accept':'application/rss+xml, application/xml, text/xml'},signal:AbortSignal.timeout(12000)});
  if(!response.ok)throw new Error('Sumber berita sedang tidak tersedia.');
  const xml=await response.text();
  if(xml.length>2000000)throw new Error('Respons sumber terlalu besar.');
  const items=parseFeed(xml);
  if(items.length<3)throw new Error('Tiga berita terbaru belum tersedia dari sumber.');
  const edition={updatedAt:new Date().toISOString(),items};
  await env.BUCKET.put(NEWS_KEY,JSON.stringify(edition),{httpMetadata:{contentType:'application/json'}});
  return edition;
}
export default {
  async fetch(request,env) {
    const url=new URL(request.url);
    try {
      if(url.pathname==='/api/insights/refresh') {
        if(request.method!=='POST')return json({error:'Gunakan POST.'},405);
        // This operation accepts no caller content or URL: it only imports three
        // recent headlines from a fixed public source, capped to once per 15 min.
        if(Number(request.headers.get('content-length')||0)>0)return json({error:'Body tidak diterima.'},400);
        const live=await refreshNews(env);
        return json({ok:true,live});
      }
      if(url.pathname==='/api/insights') {
        if(request.method!=='GET')return json({error:'Method not allowed'},405);
        let live=await readNews(env);
        let sourceAvailable=true;
        if(!live||Date.now()-Date.parse(live.updatedAt)>CACHE_MS) {
          try {live=await refreshNews(env);}catch{sourceAvailable=false;}
        }
        return json({...INITIAL_EDITION,live,sourceAvailable});
      }
      if(request.method!=='GET' && request.method!=='HEAD')return new Response('Method not allowed',{status:405});
      let path;
      try {path=decodeURIComponent(url.pathname);}catch{return new Response('Bad request',{status:400});}
      if(path.includes('..'))return new Response('Not found',{status:404});
      const key=path==='/'?'/index.html':path.endsWith('/')?path+'index.html':path;
      const asset=ASSETS[key]||ASSETS[key+'/index.html'];
      if(!asset)return new Response('Not found',{status:404});
      const body=request.method==='HEAD'?null:Uint8Array.from(atob(asset.data),c=>c.charCodeAt(0));
      return new Response(body,{headers:{'Content-Type':asset.type,'Cache-Control':key.startsWith('/_next/static/')?'public, max-age=31536000, immutable':'public, max-age=0, must-revalidate','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'}});
    }catch(error){return json({ok:false,error:error instanceof Error?error.message:'Pembaruan gagal.'},503);}
  }
};
