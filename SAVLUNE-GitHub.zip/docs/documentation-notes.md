# Catatan unggahan dan konteks publikasi

Founder telah mengonfirmasi bahwa dua tangkapan PNL adalah miliknya dan menyebut tanggal 5 Juni untuk dokumen hukum. Jawaban tersebut belum menetapkan tahun terbit, identitas lembaga penerbit, atau status akun riil/demo. Tiga dokumen hukum ditampilkan sebagai dokumentasi pribadi di `src/components/sections/personal-documentation.tsx`, dengan data terpisah di `src/data/documentation.ts` dan versi WebP di `public/images/documentation/`. Gambar tidak diubah isi, tanggal, tanda tangan, atau angkanya.

## Dokumen hukum

| File           | Topik tercetak      | Periode belajar          | Tanggal terbit tercetak | Informasi yang perlu dilengkapi                                                       |
| -------------- | ------------------- | ------------------------ | ----------------------- | ------------------------------------------------------------------------------------- |
| 1000228697.jpg | Hukum Perdata       | 22 Februari–27 Juli 2026 | 5 Juni 2025             | Identitas lembaga penerbit dan penjelasan tanggal terbit yang mendahului masa belajar |
| 1000228696.jpg | Hukum Pidana        | 22 Februari–27 Juli 2026 | 5 Juni 2025             | Identitas lembaga penerbit dan penjelasan tanggal terbit yang mendahului masa belajar |
| 1000228686.jpg | Hukum Perdata Acara | 22 Februari–27 Juli 2026 | Tidak terlihat          | Identitas lembaga penerbit, tanggal terbit, dan nomor dokumen jika ada                |

Dokumen mencantumkan nama Muhammad Luthfi Yannur. Sebutan advokat pada salah satu bagian tanda tangan tidak menetapkan status penerima sebagai advokat. Tidak dilakukan pemeriksaan penerbit. Tanggal pada kartu mengikuti teks gambar, sedangkan ketidaksesuaian tahun dijelaskan di galeri. Identitas lembaga tidak ditebak. Dokumen ini tidak digunakan untuk menyatakan kelulusan S1, lisensi profesi, maupun kualifikasi mengajar.

Gambar PNL investasi dan galeri Dokumentasi Market Pribadi telah dihapus atas permintaan founder.
