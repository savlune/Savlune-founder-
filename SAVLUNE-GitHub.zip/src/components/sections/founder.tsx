import Image from "next/image";
import { ArrowUpRight, Check, MapPin } from "lucide-react";
import { founder } from "@/data/founder";
import { getWhatsAppUrl } from "@/lib/whatsapp";
import { BrandMark } from "../ui/brand-mark";
import { WhatsAppIcon } from "../ui/whatsapp-icon";
import { Reveal } from "../ui/reveal";

export function Founder() {
  const photo: string | null = founder.photo;
  return (
    <section id="founder" className="section founder-section">
      <div className="container founder-layout">
        <Reveal className="founder-portrait">
          <div className="portrait-topline">
            <span>SAVLUNE / FOUNDER PROFILE</span>
            <BrandMark className="portrait-mark" />
          </div>
          <div className="portrait-image">
            {photo ? (
              <Image
                src={photo}
                alt={`Foto ${founder.name}, ${founder.role}`}
                fill
                sizes="(max-width: 767px) 90vw, 420px"
                className="founder-photo"
              />
            ) : (
              <div
                className="founder-monogram"
                aria-label={`Monogram ${founder.name}`}
              >
                <div className="monogram-orbit orbit-one" />
                <div className="monogram-orbit orbit-two" />
                <div className="monogram-orbit orbit-three" />
                <span>
                  {founder.initials}
                  <span className="monogram-period">.</span>
                </span>
                <p>THE PERSON BEHIND THE VISION</p>
              </div>
            )}
          </div>
          <div className="portrait-caption">
            <div>
              <span className="portrait-caption-label">DRIVEN BY PURPOSE</span>
              <p>Belajar. Membangun. Bertumbuh.</p>
            </div>
            <span className="portrait-star">✦</span>
          </div>
          <div className="portrait-location">
            <MapPin size={13} />
            Samarinda, Kalimantan Timur<span>INDONESIA</span>
          </div>
        </Reveal>
        <Reveal className="founder-content" delay={0.1}>
          <p className="section-eyebrow">
            <span>03</span>
            <span className="eyebrow-line" />
            MEET THE FOUNDER
          </p>
          <h2 className="section-title">
            Profil <em>Founder.</em>
          </h2>
          <div className="founder-name-block">
            <h3>{founder.name}</h3>
            <span className="founder-role">{founder.role}</span>
          </div>
          <p className="founder-subtitle">{founder.subtitle}</p>
          <p className="body-copy founder-bio">{founder.description}</p>
          <ul className="founder-facts">
            {founder.facts.map((fact) => (
              <li key={fact}>
                <span>
                  <Check size={12} />
                </span>
                {fact}
              </li>
            ))}
          </ul>
          <div className="founder-buttons">
            <a
              className="button button-gold"
              href={getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
            >
              <WhatsAppIcon size={19} />
              Chat via WhatsApp
              <ArrowUpRight size={16} />
            </a>
            <a
              className="button button-outline"
              href={getWhatsAppUrl(
                "Halo, saya ingin konsultasi awal dengan Founder SAVLUNE.",
              )}
              target="_blank"
              rel="noopener noreferrer"
            >
              Konsultasi Awal
              <ArrowUpRight size={16} />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
