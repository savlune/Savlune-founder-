"use client";
import Image from "next/image";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { founder } from "@/data/founder";
import { getWhatsAppUrl } from "@/lib/whatsapp";
import { OrbitalArt } from "../ui/orbital-art";
import { Reveal } from "../ui/reveal";

export function Hero() {
  return <section id="beranda" className="editorial-hero">
    <div className="container">
      <div className="opening-quote"><blockquote>“The only way to do great work is to love what you do.”</blockquote><a href="https://news.stanford.edu/stories/2005/06/youve-got-find-love-jobs-says" target="_blank" rel="noopener noreferrer">Steve Jobs · Stanford, 2005 <ArrowUpRight size={12}/></a></div>
      <div className="editorial-hero-grid">
        <Reveal className="editorial-hero-copy"><p className="hero-kicker">SITUS RESMI PRIBADI / MUHAMMAD LUTHFI YANNUR</p><h1>SAVLUNE<span>.</span></h1><h2>Visi yang luas.<br/>Langkah yang <em>berarti.</em></h2><p className="editorial-hero-description">Saya Luthfi. Founder SAVLUNE, mahasiswa hukum, dan wirausaha dari Samarinda. Di sini saya berbagi perjalanan, gagasan bisnis, dan perspektif tentang dunia yang terus berubah.</p><div className="editorial-hero-actions"><a className="button button-gold" href={getWhatsAppUrl()} target="_blank" rel="noopener noreferrer">Mari terhubung <ArrowUpRight size={18}/></a><a className="button button-text" href="#insight">Baca global insight <ArrowDown size={16}/></a></div><div className="editorial-signature"><span>MLY</span><p>Muhammad Luthfi Yannur<small>FOUNDER SAVLUNE · SAMARINDA</small></p></div></Reveal>
        <Reveal className="editorial-hero-visual" delay={0.12}><div className="portrait-orbit"><OrbitalArt/></div><div className="editorial-photo-frame"><Image src={founder.photo} alt="Muhammad Luthfi Yannur, Founder SAVLUNE" width={1000} height={1000} priority sizes="(max-width: 767px) 85vw, 460px"/><div className="portrait-overlay"><span>THE PERSON BEHIND THE VISION</span><strong>Belajar.<br/>Membangun.<br/><em>Bertumbuh.</em></strong></div></div><div className="portrait-side-label">INDEPENDENT MIND / SHARED AMBITION</div><span className="hero-visual-number">01 / THE FOUNDER</span></Reveal>
      </div>
      <div className="editorial-hero-bottom"><span>ENTREPRENEURSHIP</span><i>✦</i><span>GLOBAL PERSPECTIVE</span><i>✦</i><span>LEGAL INSIGHT</span><a href="#founder">Kenali saya <ArrowDown size={15}/></a></div>
    </div>
  </section>;
}
