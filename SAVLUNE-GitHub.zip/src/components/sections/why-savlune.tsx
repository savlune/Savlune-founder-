import { Icon } from "@/components/ui/icon";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeading } from "@/components/ui/section-heading";
import { whySavlune } from "@/data/trust";

export function WhySavlune() {
  return (
    <section
      id="mengapa"
      className="section why-section"
      aria-label="Mengapa SAVLUNE"
    >
      <div className="container">
        <SectionHeading
          number="06"
          label="THE SAVLUNE APPROACH"
          title={
            <>
              Mengapa <em>SAVLUNE?</em>
            </>
          }
        >
          Lebih dekat secara personal. Lebih terarah dalam setiap percakapan.
        </SectionHeading>

        <div className="why-grid">
          {whySavlune.map((item, index) => (
            <Reveal key={item.title} className="why-item" delay={index * 0.045}>
              <span className="why-icon">
                <Icon name={item.icon} size={23} />
              </span>
              <div className="why-content">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
