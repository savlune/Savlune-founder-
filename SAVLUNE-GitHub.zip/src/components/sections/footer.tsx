import { ArrowUpRight } from "lucide-react";
import { BrandMark } from "@/components/ui/brand-mark";
import { footerNavigation } from "@/data/navigation";
import { getWhatsAppUrl } from "@/lib/whatsapp";

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-top">
          <div className="footer-identity">
            <a
              className="footer-brand"
              href="#beranda"
              aria-label="SAVLUNE — kembali ke beranda"
            >
              <BrandMark className="footer-mark" />
              <span>SAVLUNE</span>
            </a>
            <p className="footer-tagline">Vision. Strategy. Growth.</p>
            <p className="footer-location">
              Situs resmi pribadi Muhammad Luthfi Yannur, Founder SAVLUNE.
            </p>
          </div>

          <nav className="footer-nav" aria-label="Navigasi footer">
            {footerNavigation.map((item) => (
              <a key={item.href} href={item.href}>
                {item.label}
              </a>
            ))}
          </nav>

          <a
            className="footer-connect"
            href={getWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
          >
            Mari berbincang <ArrowUpRight size={16} aria-hidden="true" />
          </a>
        </div>

        <div className="footer-bottom">
          <p className="footer-copyright">
            © 2026 SAVLUNE. All Rights Reserved.
          </p>
          <p className="footer-disclaimer">
            Informasi pada website ini bersifat informatif dan edukatif. Konten
            keuangan maupun hukum bukan pengganti nasihat profesional resmi.
          </p>
        </div>
      </div>
    </footer>
  );
}
