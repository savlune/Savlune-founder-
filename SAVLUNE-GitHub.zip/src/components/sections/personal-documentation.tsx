import { TopicScene } from "../ui/topic-scene";
import Image from "next/image";
import {
  ArrowUpRight,
  BookOpen,
} from "lucide-react";
import { Reveal } from "@/components/ui/reveal";
import { legalDocuments } from "@/data/documentation";

export function PersonalDocumentation() {
  return (
    <div className="personal-documentation">
      <section aria-labelledby="legal-documentation-title">
        <div className="law-scene-banner">
          <div className="law-scene-background"><TopicScene topic="legal" /></div>
        <Reveal className="documentation-heading">
          <span className="documentation-heading-icon" aria-hidden="true">
            <BookOpen size={23} />
          </span>
          <div>
            <h3 id="legal-documentation-title">
              Dokumen Hukum
            </h3>
            <p>Dokumentasi belajar.</p>
          </div>
        </Reveal>
        </div>

        <div className="legal-documents-grid">
          {legalDocuments.map((document, index) => (
            <Reveal key={document.id} delay={index * 0.06}>
              <article className="legal-document-card">
                <div className="documentation-image-wrap">
                  <Image
                    src={document.image}
                    alt={document.alt}
                    width={document.width}
                    height={document.height}
                    sizes="(max-width: 767px) 90vw, (max-width: 1199px) 44vw, 350px"
                    loading="lazy"
                    className="documentation-image"
                  />
                </div>
                <div className="documentation-content">
                  <h4>{document.title}</h4>
                  <a
                    className="documentation-link"
                    href={document.image}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`Lihat dokumen pembelajaran ${document.title} (buka di tab baru)`}
                  >
                    Lihat dokumen
                    <ArrowUpRight size={16} aria-hidden="true" />
                  </a>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

    </div>
  );
}
