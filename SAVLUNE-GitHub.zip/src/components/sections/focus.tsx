import { TopicScene } from "../ui/topic-scene";
import { ArrowUpRight, Check, Info } from "lucide-react";
import { focusAreas } from "@/data/focus";
import { Icon } from "../ui/icon";
import { Reveal } from "../ui/reveal";
import { SectionHeading } from "../ui/section-heading";

export function Focus() {
  return (
    <section id="fokus" className="section focus-section">
      <div className="container">
        <div className="section-heading-row">
          <SectionHeading
            number="02"
            label="THREE PERSPECTIVES. ONE VISION."
            title={
              <>
                Bidang Fokus <em>SAVLUNE.</em>
              </>
            }
          >
            Bisnis, keuangan, dan hukum dalam kegiatan sehari-hari.
          </SectionHeading>
          <a href="#konsultasi" className="text-link">
            Temukan ruang diskusi
            <ArrowUpRight size={18} />
          </a>
        </div>
        <div className="focus-grid">
          {focusAreas.map((area, i) => (
            <Reveal
              key={area.id}
              delay={i * 0.1}
              className={`focus-card focus-card-${area.id}`}
            >
              <TopicScene topic={area.id === "legal" ? "legal" : area.id === "finance" ? "finance" : "business"} compact />
              <div className="focus-card-top">
                <Icon name={area.icon} size={31} />
                <span>{area.number} /</span>
              </div>
              <p className="focus-label">{area.label}</p>
              <h3>{area.title}</h3>
              <p className="focus-description">{area.description}</p>
              <ul className="focus-topics">
                {area.topics.map((topic) => (
                  <li key={topic}>
                    <Check size={14} />
                    {topic}
                  </li>
                ))}
              </ul>
              {area.disclaimer ? (
                <p className="focus-disclaimer">
                  <Info size={13} />
                  <span>{area.disclaimer}</span>
                </p>
              ) : (
                <div className="focus-business-note">
                  <span className="tiny-star">✦</span>Ide yang baik dimulai dari
                  percakapan.
                </div>
              )}
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
