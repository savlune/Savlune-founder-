"use client";
import { useState, type FormEvent } from "react";
import { ArrowUpRight, Quote } from "lucide-react";
import { getWhatsAppUrl } from "@/lib/whatsapp";
import { Reveal } from "../ui/reveal";

export function Sponsors() {
  const sponsors=["RF collection", "LUCIANO", "CLOIS PROPERTI", "CL", "second murah Samarinda", "TDA SAMARINDA"];
  return <section id="sponsor" className="sponsor-section"><div className="container"><div className="sponsor-intro"><p>SPONSOR & PENDUKUNG</p><h2>Bertumbuh bersama.</h2></div><div className="sponsor-wordmarks">{sponsors.map((name,i)=><span key={name} className={`sponsor-wordmark sponsor-wordmark-${i}`}>{name}</span>)}</div></div></section>;
}
export function Community() {
  const [ready,setReady]=useState<string|null>(null);
  function prepare(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data=new FormData(event.currentTarget);
    setReady(getWhatsAppUrl(`Halo SAVLUNE, saya ingin membagikan pengalaman.\nNama: ${data.get("name")}\nTahun pengalaman: ${data.get("year")}\nHubungan: ${data.get("relationship")}\nCerita: ${data.get("story")}\nSaya mengizinkan cerita dan nama ini ditampilkan setelah disetujui.`));
  }
  return <section id="cerita" className="section community-section"><div className="container community-grid"><Reveal><p className="section-eyebrow">SUARA DARI PERJALANAN</p><h2 className="section-title">Setiap kolaborasi<br/>punya <em>cerita.</em></h2><p className="body-copy">Pernah bekerja sama dengan saya atau SAVLUNE? Ceritakan pengalaman Anda.</p><div className="community-note"><Quote size={32}/><p>Cerita Anda membantu saya bekerja lebih baik.</p></div></Reveal><form className="story-form" onSubmit={prepare} onChange={()=>setReady(null)}><h3>Bagikan pengalaman Anda</h3><p>Cerita dikirim melalui WhatsApp untuk ditinjau sebelum ditampilkan.</p><label>Nama<input name="name" required maxLength={80} placeholder="Nama Anda" autoComplete="name"/></label><div className="story-fields"><label>Tahun pengalaman<select name="year" required><option value="">Pilih tahun</option>{[2026,2025,2024,2023,2022,2021].map(y=><option key={y}>{y}</option>)}</select></label><label>Hubungan<select name="relationship" required><option>Rekan usaha</option><option>Pelanggan</option><option>Teman diskusi</option><option>Lainnya</option></select></label></div><label>Cerita Anda<textarea name="story" required minLength={20} maxLength={1200} rows={4} placeholder="Ceritakan pengalaman spesifik Anda…"/></label><label className="story-consent"><input type="checkbox" required/>Saya mengizinkan nama dan cerita ini ditampilkan.</label>{ready?<a className="button button-gold" href={ready} target="_blank" rel="noopener noreferrer">Lanjut kirim via WhatsApp <ArrowUpRight size={18}/></a>:<button className="button button-gold" type="submit">Siapkan cerita <ArrowUpRight size={18}/></button>}</form></div></section>;
}
