"use client";

import { useEffect, useState } from "react";
import { ArrowUpRight, RefreshCw } from "lucide-react";
import initialEdition from "@/data/insights.json";
import { TopicScene } from "../ui/topic-scene";
import { Reveal } from "../ui/reveal";

type LiveNews = { updatedAt: string; items: { title: string; url: string; publishedAt: string; source: string; category?: string }[] };
type Edition = typeof initialEdition & { live?: LiveNews | null; sourceAvailable?: boolean };
function dateLabel(value: string) {
  return new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Makassar" }).format(new Date(value));
}
function EditorialArt({ kind }: { kind: string }) {
  const topic = kind === "commodity" ? "commodity" : kind === "currency" ? "currency" : kind === "business" ? "business" : "finance";
  return <div className={`editorial-art editorial-art-${kind}`}><TopicScene topic={topic}/></div>;
}
export function GlobalInsights() {
  const [edition,setEdition]=useState<Edition>(initialEdition);
  const [filter,setFilter]=useState("Semua");
  const [status,setStatus]=useState("Edisi tersimpan");
  const [busy,setBusy]=useState(false);
  async function refresh() {
    setBusy(true);
    try {
      const response=await fetch("/Savlune-founder-/news.json",{cache:"no-store"});
      if(!response.ok) throw new Error("unavailable");
      const next=await response.json() as Edition;
      if(!Array.isArray(next.items)||next.items.length<3) throw new Error("invalid");
      setEdition(next); setStatus(next.sourceAvailable === false ? "Sumber sedang tidak tersedia; edisi terakhir" : "Terhubung ke sumber berita");
    } catch { setStatus("Menampilkan edisi tersimpan"); }
    finally { setBusy(false); }
  }
  useEffect(()=>{ void refresh(); const timer=setInterval(()=>{if(document.visibilityState==="visible")void refresh();},60000);return ()=>clearInterval(timer);},[]);
  const categories=["Semua",...Array.from(new Set(edition.items.map(item=>item.category)))];
  const shown=edition.items.filter(item=>filter==="Semua"||item.category===filter);
  return <section id="insight" className="editorial-section">
    <div className="container">
      <div className="editorial-topline"><span>THE SAVLUNE JOURNAL</span><span>BISNIS · KOMODITAS · MATA UANG · PERUSAHAAN</span></div>
      <Reveal className="editorial-heading"><div><p className="editorial-eyebrow">CATATAN PASAR</p><h2>Bisnis &amp; <em>pasar global.</em></h2></div><p>Berita bisnis, komoditas, mata uang, dan perusahaan.</p></Reveal>
      <div className="edition-meta"><span><i aria-hidden="true" />{status}</span><span>Diperbarui {dateLabel(edition.updatedAt)}</span><button type="button" onClick={refresh} disabled={busy}><RefreshCw size={14} className={busy?"is-refreshing":""}/>{busy?"Memeriksa…":"Periksa pembaruan"}</button></div>
      {edition.live && <aside className="live-news" aria-label="Tiga kabar terkini"><div className="live-news-title"><span><i/>KABAR TERKINI</span><p>Diperiksa {dateLabel(edition.live.updatedAt)} · Judul asli dari BBC News</p></div><div className="live-news-grid">{edition.live.items.map((item,index)=><a key={item.url} href={item.url} target="_blank" rel="noopener noreferrer"><span>0{index+1}</span><div>{item.category && <span className="live-topic">{item.category}</span>}<h3>{item.title}</h3><small>{dateLabel(item.publishedAt)} · {item.source}</small></div><ArrowUpRight size={18}/></a>)}</div></aside>}
      <p className="analysis-edition-label">ANALISIS PILIHAN · EDISI {dateLabel(edition.updatedAt).toUpperCase()}</p>
      <div className="insight-filters" aria-label="Kategori insight">{categories.map(category=><button type="button" key={category} aria-pressed={filter===category} onClick={()=>setFilter(category)}>{category}</button>)}</div>
      <div className="insight-grid">{shown.map((item,index)=><article className="insight-card" key={item.id}>
        <EditorialArt kind={item.visual}/><div className="insight-card-body"><div className="insight-category"><span>{item.category}</span><span>0{index+1}</span></div><h3>{item.title}</h3><p>{item.summary}</p><details><summary>Catatan singkat <span>+</span></summary><p>{item.insight}</p></details><a href={item.url} target="_blank" rel="noopener noreferrer"><span>{item.source}<small>{dateLabel(item.publishedAt)}</small></span><ArrowUpRight size={20}/></a></div>
      </article>)}</div>
      <p className="editorial-footnote">Ringkasan berita merujuk sumber yang ditautkan. Catatan singkat merupakan interpretasi editorial. Edisi berkala, bukan umpan harga waktu nyata.</p>
    </div>
  </section>;
}
