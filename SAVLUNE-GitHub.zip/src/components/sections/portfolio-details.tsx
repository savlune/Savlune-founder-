import Image from "next/image";
import {
  ArrowUpRight,
  Award,
  BriefcaseBusiness,
  Check,
  GraduationCap,
} from "lucide-react";
import { Reveal } from "@/components/ui/reveal";
import { LearningFocus } from "./learning-focus";
import { PersonalDocumentation } from "./personal-documentation";
import {
  certificates,
  competencies,
  education,
  experience,
} from "@/data/portfolio";

export function PortfolioDetails() {
  return (
    <div className="portfolio-details">
      <Reveal className="portfolio-subheading">
        <p className="section-eyebrow">
          <span className="eyebrow-line" aria-hidden="true" />
          EXPERIENCE &amp; LEARNING
        </p>
        <h3>Pengalaman & pendidikan.</h3>
        <p>
          Penjualan, pengelolaan usaha, dan studi hukum.
        </p>
      </Reveal>

      <div className="portfolio-evidence-grid">
        <div
          className="experience-list"
          aria-label="Pengalaman kerja dan usaha"
        >
          {experience.map((item, index) => (
            <Reveal key={item.id} delay={index * 0.05}>
              <article className="experience-item">
                <div className="experience-top">
                  <span className="experience-icon" aria-hidden="true">
                    <BriefcaseBusiness size={20} />
                  </span>
                  <span className="experience-period">{item.period}</span>
                </div>
                <h4>{item.role}</h4>
                <p className="experience-organization">{item.organization}</p>
                <p className="experience-location">{item.location}</p>
                <p className="experience-description">{item.description}</p>
                {item.highlights.length > 0 && (
                  <ul className="experience-highlights">
                    {item.highlights.map((highlight) => (
                      <li key={highlight}>
                        <Check size={14} aria-hidden="true" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal className="education-card" delay={0.08}>
          <div className="education-heading">
            <span aria-hidden="true">
              <GraduationCap size={24} />
            </span>
            <h3>Pendidikan</h3>
          </div>
          <div className="education-content">
            <h4>{education.program}</h4>
            <p className="education-institution">{education.institution}</p>
            <p className="education-period">{education.period}</p>
            <span className="education-status">{education.status}</span>
          </div>
          <div className="competency-block">
            <h4>Kompetensi &amp; Keterampilan</h4>
            <ul className="competency-list">
              {competencies.map((competency) => (
                <li key={competency}>{competency}</li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>

      <LearningFocus />

      <Reveal className="certifications-header">
        <span className="certifications-icon" aria-hidden="true">
          <Award size={23} />
        </span>
        <div>
          <h3>Sertifikat Pelatihan</h3>
          <p>
            Komunikasi & pelayanan pelanggan.
          </p>
        </div>
      </Reveal>

      <div className="certificates-grid">
        {certificates.map((certificate, index) => (
          <Reveal key={certificate.id} delay={index * 0.06}>
            <article className="certificate-card">
              <div className="certificate-image-wrap">
                <Image
                  src={certificate.image}
                  alt={certificate.alt}
                  width={certificate.width}
                  height={certificate.height}
                  sizes="(max-width: 767px) 90vw, (max-width: 1199px) 44vw, 530px"
                  loading="lazy"
                  className="certificate-image"
                />
              </div>
              <div className="certificate-content">
                <h4>{certificate.title}</h4>
                <p className="certificate-issuer">{certificate.issuer}</p>
                <p className="certificate-date">
                  {certificate.period || certificate.date}
                </p>
                <a
                  className="certificate-link"
                  href={certificate.image}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Lihat sertifikat ${certificate.title} dari ${certificate.issuer}`}
                >
                  Lihat sertifikat
                  <ArrowUpRight size={16} aria-hidden="true" />
                </a>
              </div>
            </article>
          </Reveal>
        ))}
      </div>

      <PersonalDocumentation />
    </div>
  );
}
