import { Check } from "lucide-react";
import { Icon } from "@/components/ui/icon";
import { Reveal } from "@/components/ui/reveal";
import { SectionHeading } from "@/components/ui/section-heading";
import { founderBadges, trustBackgrounds, trustReasons } from "@/data/trust";
import { PortfolioDetails } from "./portfolio-details";

export function Trust() {
  return (
    <section
      id="portofolio"
      className="section trust-section"
      aria-label="Portofolio dan kepercayaan"
    >
      <div className="container">
        <SectionHeading
          number="04"
          label="BUILT ON TRUST"
          title={
            <>
              Portofolio &amp; <em>Kepercayaan.</em>
            </>
          }
        >
          Fondasi yang terus dibangun melalui pendidikan, semangat berwirausaha,
          dan komitmen untuk berkembang.
        </SectionHeading>

        <div className="trust-grid">
          {trustBackgrounds.map((item, index) => (
            <Reveal
              key={item.title}
              className="trust-card"
              delay={index * 0.06}
            >
              <article>
                <div className="trust-card-top">
                  <span className="trust-card-icon">
                    <Icon name={item.icon} size={25} />
                  </span>
                  <span className="trust-card-number" aria-hidden="true">
                    0{index + 1}
                  </span>
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <ul
            className="founder-badges"
            aria-label="Identitas dan bidang minat founder"
          >
            {founderBadges.map((badge) => (
              <li key={badge}>{badge}</li>
            ))}
          </ul>
        </Reveal>

        <PortfolioDetails />

        <Reveal className="trust-panel">
          <div className="trust-panel-intro">
            <span className="trust-panel-symbol" aria-hidden="true">
              <Icon name="ShieldCheck" size={29} />
            </span>
            <h3>Kenapa Bisa Dipercaya?</h3>
            <p>
              Berawal dari identitas yang jelas, informasi yang terbuka, dan
              komunikasi yang mudah.
            </p>
          </div>
          <ul className="trust-reasons">
            {trustReasons.map((reason) => (
              <li key={reason}>
                <Check size={16} aria-hidden="true" />
                <span>{reason}</span>
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
