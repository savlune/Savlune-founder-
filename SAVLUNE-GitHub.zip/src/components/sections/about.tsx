import { brand, coreValues } from "@/data/brand";
import { Icon } from "../ui/icon";
import { Reveal } from "../ui/reveal";
import { SectionHeading } from "../ui/section-heading";

export function About() {
  return (
    <section id="tentang" className="section about-section">
      <div className="container">
        <div className="about-layout">
          <SectionHeading
            number="01"
            label="THE IDEA BEHIND SAVLUNE"
            title={
              <>
                Tentang <em>SAVLUNE.</em>
              </>
            }
          />
          <Reveal className="about-story">
            <p className="about-lead">
              Sebuah visi. Beragam perspektif.
              <br />
              <span>Satu arah untuk terus bertumbuh.</span>
            </p>
            <p className="body-copy">{brand.about}</p>
          </Reveal>
        </div>
        <div className="values-grid">
          {coreValues.map((value, i) => (
            <Reveal key={value.number} delay={i * 0.08} className="value-card">
              <div className="value-card-top">
                <span className="icon-tile">
                  <Icon name={value.icon} size={22} />
                </span>
                <span className="card-index">{value.number}</span>
              </div>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
