import { ArrowUpRight, Plus } from "lucide-react";
import { services } from "@/data/services";
import { getWhatsAppUrl } from "@/lib/whatsapp";
import { Icon } from "../ui/icon";
import { Reveal } from "../ui/reveal";
import { SectionHeading } from "../ui/section-heading";
import { WhatsAppIcon } from "../ui/whatsapp-icon";

export function Services() {
  return (
    <section id="konsultasi" className="section services-section">
      <div className="container">
        <SectionHeading
          number="05"
          label="LET’S START A CONVERSATION"
          title={
            <>
              Bisa Konsultasi
              <br />
              Tentang <em>Apa?</em>
            </>
          }
        >
          Setiap langkah besar bisa berawal dari diskusi sederhana. Pilih topik
          Anda, lalu mari bertukar perspektif.
        </SectionHeading>
        <div className="services-grid">
          {services.map((service, i) => (
            <Reveal
              key={service.id}
              className="service-card"
              delay={(i % 3) * 0.06}
            >
              <div className="service-top">
                <span className="icon-tile">
                  <Icon name={service.icon} size={24} />
                </span>
                <span className="card-index">{service.number}</span>
              </div>
              <h3>{service.title}</h3>
              <p className="service-description">{service.description}</p>
              <ul>
                {service.topics.map((topic) => (
                  <li key={topic}>
                    <Plus size={12} />
                    {topic}
                  </li>
                ))}
              </ul>
              {"note" in service && service.note && (
                <p className="service-note">{service.note}</p>
              )}
              <a
                href={getWhatsAppUrl(service.whatsappMessage)}
                className="service-link"
                target="_blank"
                rel="noopener noreferrer"
              >
                <WhatsAppIcon size={18} />
                <span>Konsultasi via WhatsApp</span>
                <ArrowUpRight size={17} />
              </a>
            </Reveal>
          ))}
          <Reveal className="service-invite">
            <div className="invite-star">✦</div>
            <p>AN OPEN INVITATION</p>
            <h3>
              Punya ide
              <br />
              yang <em>berbeda?</em>
            </h3>
            <span>
              Ruang diskusi selalu terbuka untuk perspektif dan peluang baru.
            </span>
            <a
              href={getWhatsAppUrl(
                "Halo, saya memiliki ide dan ingin berdiskusi dengan Founder SAVLUNE.",
              )}
              className="button button-outline"
              target="_blank"
              rel="noopener noreferrer"
            >
              Konsultasi Sekarang
              <ArrowUpRight size={17} />
            </a>
          </Reveal>
        </div>
        <p className="services-disclaimer">
          Diskusi bersifat informatif dan edukatif. Tidak menyediakan layanan
          advokat resmi maupun nasihat investasi berlisensi.
        </p>
      </div>
    </section>
  );
}
