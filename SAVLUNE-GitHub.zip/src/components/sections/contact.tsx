"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  ArrowUpRight,
  LoaderCircle,
  Mail,
  MapPin,
  MessageCircle,
} from "lucide-react";
import { Reveal } from "@/components/ui/reveal";
import { contact } from "@/data/contact";
import { buildContactMessage, getWhatsAppUrl } from "@/lib/whatsapp";

const purposes = [
  { label: "Diskusi bisnis dasar", value: "berdiskusi tentang bisnis dasar" },
  {
    label: "Market & keuangan edukatif",
    value: "berdiskusi tentang market dan keuangan secara edukatif",
  },
  {
    label: "Literasi hukum dasar",
    value: "bertanya tentang literasi hukum dasar",
  },
  { label: "Kolaborasi & partnership", value: "berkolaborasi dengan SAVLUNE" },
  {
    label: "Personal brand",
    value: "berdiskusi tentang profil dan personal brand",
  },
];

export function Contact() {
  const [isOpening, setIsOpening] = useState(false);
  const resetTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(
    () => () => {
      if (resetTimer.current) clearTimeout(resetTimer.current);
    },
    [],
  );

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const nameField = form.elements.namedItem("nama") as HTMLInputElement;
    const messageField = form.elements.namedItem(
      "pesan",
    ) as HTMLTextAreaElement;

    for (const field of [nameField, messageField]) {
      field.setCustomValidity(
        field.value.trim() ? "" : "Mohon isi kolom ini dengan teks.",
      );
    }

    if (!form.reportValidity()) return;

    const data = new FormData(form);
    const name = String(data.get("nama") ?? "").trim();
    const purpose = String(data.get("keperluan") ?? "").trim();
    const message = String(data.get("pesan") ?? "").trim();

    setIsOpening(true);
    window.location.href = getWhatsAppUrl(
      buildContactMessage({ name, purpose, message }),
    );
    resetTimer.current = setTimeout(() => setIsOpening(false), 1800);
  }

  return (
    <section
      id="kontak"
      className="section contact-section"
      aria-labelledby="contact-title"
    >
      <div className="container contact-layout">
        <Reveal className="contact-intro">
          <p className="section-eyebrow">07 / GET IN TOUCH</p>
          <h2 id="contact-title" className="section-title">
            Mari <span>Terhubung.</span>
          </h2>
          <p className="section-description">
            Jika Anda ingin berdiskusi, berkolaborasi, atau mengenal SAVLUNE
            lebih dekat, silakan hubungi langsung melalui WhatsApp.
          </p>

          <div className="contact-details">
            <a
              className="contact-detail"
              href={getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
            >
              <span className="contact-icon">
                <MessageCircle size={19} aria-hidden="true" />
              </span>
              <span>
                <span className="contact-label">WHATSAPP</span>
                <span className="contact-value">{contact.whatsappDisplay}</span>
              </span>
              <ArrowUpRight
                size={17}
                className="contact-detail-arrow"
                aria-hidden="true"
              />
            </a>
            <a className="contact-detail" href={`mailto:${contact.email}`}>
              <span className="contact-icon">
                <Mail size={19} aria-hidden="true" />
              </span>
              <span>
                <span className="contact-label">EMAIL</span>
                <span className="contact-value">{contact.email}</span>
              </span>
              <ArrowUpRight
                size={17}
                className="contact-detail-arrow"
                aria-hidden="true"
              />
            </a>
            <div className="contact-detail">
              <span className="contact-icon">
                <MapPin size={19} aria-hidden="true" />
              </span>
              <span>
                <span className="contact-label">BERDOMISILI DI</span>
                <span className="contact-value">{contact.location}</span>
              </span>
            </div>
          </div>
          <div className="contact-note">
            <span aria-hidden="true" />
            Terbuka untuk ide, diskusi, dan kolaborasi.
          </div>
        </Reveal>

        <Reveal className="contact-form-wrap" delay={0.12}>
          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="contact-form-heading">
              <span className="contact-form-number">
                LET’S START A CONVERSATION
              </span>
              <h3>Satu pesan. Banyak kemungkinan.</h3>
              <p>Ceritakan apa yang ingin Anda diskusikan.</p>
            </div>

            <div className="contact-field">
              <label htmlFor="contact-name">
                Nama Anda <span aria-hidden="true">*</span>
              </label>
              <input
                id="contact-name"
                name="nama"
                autoComplete="name"
                placeholder="Nama lengkap Anda"
                maxLength={100}
                required
                onChange={(event) => event.currentTarget.setCustomValidity("")}
              />
            </div>

            <div className="contact-field">
              <label htmlFor="contact-purpose">
                Keperluan <span aria-hidden="true">*</span>
              </label>
              <select
                id="contact-purpose"
                name="keperluan"
                defaultValue=""
                required
              >
                <option value="" disabled>
                  Pilih topik diskusi
                </option>
                {purposes.map((purpose) => (
                  <option key={purpose.value} value={purpose.value}>
                    {purpose.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="contact-field">
              <label htmlFor="contact-message">
                Pesan <span aria-hidden="true">*</span>
              </label>
              <textarea
                id="contact-message"
                name="pesan"
                placeholder="Ceritakan ide, kebutuhan, atau pertanyaan Anda…"
                rows={4}
                maxLength={3000}
                required
                onChange={(event) => event.currentTarget.setCustomValidity("")}
              />
            </div>

            <button
              className="button button-gold contact-submit"
              type="submit"
              disabled={isOpening}
              aria-busy={isOpening}
            >
              {isOpening ? (
                <LoaderCircle
                  className="contact-submit-spinner"
                  size={18}
                  aria-hidden="true"
                />
              ) : (
                <MessageCircle size={18} aria-hidden="true" />
              )}
              <span aria-live="polite">
                {isOpening ? "Membuka WhatsApp…" : "Kirim ke WhatsApp"}
              </span>
              {!isOpening && <ArrowUpRight size={18} aria-hidden="true" />}
            </button>
            <p className="contact-form-hint">
              Pesan Anda akan diteruskan ke WhatsApp founder.
            </p>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
