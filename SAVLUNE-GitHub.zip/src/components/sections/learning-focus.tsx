import { TopicScene } from "../ui/topic-scene";
import { Check } from "lucide-react";
import { Icon } from "@/components/ui/icon";
import { Reveal } from "@/components/ui/reveal";
import { learningAreas } from "@/data/portfolio";

export function LearningFocus() {
  return (
    <div className="learning-focus">
      <Reveal className="learning-focus-heading">
        <h3>Hukum & pasar.</h3>
        <p>
          Catatan belajar dan topik diskusi.
        </p>
      </Reveal>

      <div className="learning-focus-grid">
        {learningAreas.map((area, index) => (
          <Reveal key={area.id} delay={index * 0.06}>
            <article className="learning-focus-card">
              <TopicScene topic={area.id === "legal-learning" ? "legal" : "finance"} compact />
              <span className="learning-focus-icon" aria-hidden="true">
                <Icon name={area.icon} size={25} />
              </span>
              <h4>{area.title}</h4>
              <p>{area.description}</p>
              <ul className="learning-focus-topics">
                {area.topics.map((topic) => (
                  <li key={topic}>
                    <Check size={15} aria-hidden="true" />
                    <span>{topic}</span>
                  </li>
                ))}
              </ul>
              <p className="learning-focus-note">{area.note}</p>
            </article>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
