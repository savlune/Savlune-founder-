"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { navigation } from "@/data/navigation";
import { getWhatsAppUrl } from "@/lib/whatsapp";
import { BrandMark } from "./ui/brand-mark";
import { WhatsAppIcon } from "./ui/whatsapp-icon";

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("beranda");
  const reduce = useReducedMotion();
  const toggleRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries)
          if (entry.isIntersecting) setActive(entry.target.id);
      },
      { rootMargin: "-15% 0px -65% 0px" },
    );
    navigation.forEach((item) => {
      const el = document.getElementById(item.href.slice(1));
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    menuRef.current?.querySelector<HTMLAnchorElement>("a")?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
      if (event.key !== "Tab") return;
      const elements = [
        toggleRef.current,
        ...Array.from(
          menuRef.current?.querySelectorAll<HTMLAnchorElement>("a") ?? [],
        ),
      ].filter(Boolean) as HTMLElement[];
      const first = elements[0],
        last = elements[elements.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      }
      if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    };
    const onResize = () => {
      if (window.innerWidth >= 1024) setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("resize", onResize);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onResize);
    };
  }, [open]);

  return (
    <header className="site-header">
      <div className="container nav-inner">
        <a
          href="#beranda"
          className="brand-lockup"
          aria-label="SAVLUNE — Beranda"
          onClick={() => setOpen(false)}
        >
          <BrandMark className="nav-mark" />
          <span>
            SAVLUNE<span className="brand-dot">.</span>
          </span>
        </a>
        <nav className="desktop-nav" aria-label="Navigasi utama">
          {navigation.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={active === item.href.slice(1) ? "active" : ""}
              aria-current={
                active === item.href.slice(1) ? "location" : undefined
              }
            >
              {item.label}
            </a>
          ))}
        </nav>
        <a
          className="nav-contact"
          href={getWhatsAppUrl()}
          target="_blank"
          rel="noopener noreferrer"
        >
          <WhatsAppIcon size={17} />
          <span>Hubungi WhatsApp</span>
          <ArrowUpRight size={15} />
        </a>
        <button
          ref={toggleRef}
          type="button"
          className="menu-toggle"
          aria-label={open ? "Tutup menu navigasi" : "Buka menu navigasi"}
          aria-controls="mobile-navigation"
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav
            ref={menuRef}
            id="mobile-navigation"
            className="mobile-nav"
            aria-label="Navigasi mobile"
            initial={reduce ? false : { opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22 }}
          >
            <div className="mobile-nav-label">EXPLORE SAVLUNE</div>
            {navigation.map((item, i) => (
              <a
                href={item.href}
                key={item.href}
                onClick={() => setOpen(false)}
              >
                <span className="mobile-nav-number">0{i + 1}</span>
                {item.label}
                <ArrowUpRight size={20} />
              </a>
            ))}
            <a
              href={getWhatsAppUrl()}
              className="mobile-nav-cta"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
            >
              <WhatsAppIcon />
              Hubungi WhatsApp
              <ArrowUpRight size={20} />
            </a>
            <p>Samarinda, Kalimantan Timur</p>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
