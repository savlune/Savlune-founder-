"use client";

import { useEffect, useState } from "react";
import { ArrowUp } from "lucide-react";
import { getWhatsAppUrl } from "@/lib/whatsapp";
import { WhatsAppIcon } from "./ui/whatsapp-icon";

export function FloatingActions() {
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const scroll = () => setShowTop(window.scrollY > 650);
    scroll();
    window.addEventListener("scroll", scroll, { passive: true });
    return () => window.removeEventListener("scroll", scroll);
  }, []);
  return (
    <div className="floating-actions">
      {showTop && (
        <a href="#beranda" className="scroll-top" aria-label="Kembali ke atas">
          <ArrowUp size={19} />
        </a>
      )}
      <a
        href={getWhatsAppUrl()}
        target="_blank"
        rel="noopener noreferrer"
        className="floating-whatsapp"
        aria-label="Chat SAVLUNE melalui WhatsApp"
      >
        <span className="floating-wa-label">Chat Founder</span>
        <WhatsAppIcon size={26} />
        <span className="online-dot" />
      </a>
    </div>
  );
}
