export function OrbitalArt() {
  return (
    <svg
      className="orbital-svg"
      viewBox="0 0 640 640"
      fill="none"
      shapeRendering="geometricPrecision"
      aria-hidden="true"
    >
      <defs>
        <radialGradient id="sphere-fill" cx=".28" cy=".2" r=".95">
          <stop stopColor="#6B552E" />
          <stop offset=".35" stopColor="#1C201D" />
          <stop offset=".78" stopColor="#0B1114" />
          <stop offset="1" stopColor="#080B0F" />
        </radialGradient>
        <linearGradient
          id="orbit-gold"
          x1="80"
          y1="160"
          x2="580"
          y2="470"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#584321" />
          <stop offset=".26" stopColor="#E9D6A3" />
          <stop offset=".48" stopColor="#B08843" />
          <stop offset=".7" stopColor="#F2DEAD" />
          <stop offset="1" stopColor="#68502B" />
        </linearGradient>
        <linearGradient
          id="sphere-lines"
          x1="160"
          y1="160"
          x2="450"
          y2="420"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#DDC68B" stopOpacity=".7" />
          <stop offset="1" stopColor="#B89757" stopOpacity=".08" />
        </linearGradient>
        <linearGradient
          id="symbol-gold"
          x1="230"
          y1="200"
          x2="400"
          y2="400"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#F3E7C9" />
          <stop offset=".3" stopColor="#DDC18B" />
          <stop offset=".6" stopColor="#A28347" />
          <stop offset="1" stopColor="#E8C887" />
        </linearGradient>
        <radialGradient id="halo">
          <stop stopColor="#D6B56B" stopOpacity=".14" />
          <stop offset="1" stopColor="#D6B56B" stopOpacity="0" />
        </radialGradient>
        <clipPath id="sphere-clip">
          <circle cx="320" cy="300" r="156" />
        </clipPath>
      </defs>
      <circle className="orbit-halo" cx="320" cy="300" r="290" fill="url(#halo)" />
      <circle cx="320" cy="300" r="254" stroke="#D6B56B" strokeOpacity=".09" />
      <circle
        cx="320"
        cy="300"
        r="226"
        stroke="#D6B56B"
        strokeOpacity=".06"
        strokeDasharray="2 7"
      />
      <g className="orbit-dial" opacity=".3">
        {Array.from({ length: 60 }, (_, i) => (
          <line
            key={i}
            x1="320"
            y1={i % 5 === 0 ? "38" : "43"}
            x2="320"
            y2="48"
            stroke="#D6B56B"
            strokeWidth={i % 5 === 0 ? 1 : 0.6}
            transform={`rotate(${i * 6} 320 300)`}
          />
        ))}
      </g>
      <g className="orbit-satellites">
        <circle cx="320" cy="300" r="254" stroke="url(#orbit-gold)" strokeWidth="1.4" strokeDasharray="100 1496" strokeLinecap="round" />
        <circle cx="574" cy="300" r="10" fill="#E9D6A3" fillOpacity=".08" />
        <circle cx="574" cy="300" r="4" fill="#F3E7C9" />
        <circle cx="66" cy="300" r="2.5" fill="#D6B56B" />
      </g>
      <g className="orbit-satellites orbit-satellites-inner">
        <circle cx="320" cy="300" r="226" stroke="url(#orbit-gold)" strokeWidth=".8" strokeDasharray="56 1364" strokeLinecap="round" />
        <circle cx="546" cy="300" r="2.5" fill="#E9D6A3" />
      </g>
      <g className="orbit-stars" fill="#F1DCAC">
        {Array.from({ length: 14 }, (_, i) => {
          const angle = (i * 137.5 * Math.PI) / 180;
          const radius = 185 + (i % 4) * 24;
          return <circle key={i} cx={320 + Math.cos(angle) * radius} cy={300 + Math.sin(angle) * radius} r={i % 3 === 0 ? 1.8 : 1} style={{ animationDelay: `${-i * 0.7}s` }} />;
        })}
      </g>
      <g className="orbit-back">
        <ellipse
          cx="320"
          cy="300"
          rx="260"
          ry="100"
          transform="rotate(-35 320 300)"
          stroke="url(#orbit-gold)"
          strokeWidth="1.2"
        />
        <ellipse
          cx="320"
          cy="300"
          rx="244"
          ry="88"
          transform="rotate(-35 320 300)"
          stroke="#D6B56B"
          strokeOpacity=".15"
          strokeWidth=".6"
        />
      </g>
      <circle
        cx="320"
        cy="300"
        r="156"
        fill="url(#sphere-fill)"
        stroke="url(#orbit-gold)"
        strokeWidth=".9"
      />
      <g
        clipPath="url(#sphere-clip)"
        stroke="url(#sphere-lines)"
        strokeWidth=".65"
      >
        {[-138, -115, -86, -48, 0, 48, 86, 115, 138].map((offset, i) => (
          <ellipse
            key={`v${i}`}
            cx="320"
            cy="300"
            rx={Math.max(12, 156 - Math.abs(offset))}
            ry="156"
            transform={`rotate(-22 320 300)`}
          />
        ))}
        {[-126, -90, -46, 0, 46, 90, 126].map((offset, i) => (
          <ellipse
            key={`h${i}`}
            cx="320"
            cy={300 + offset}
            rx={Math.sqrt(156 * 156 - offset * offset)}
            ry="24"
            transform="rotate(-22 320 300)"
          />
        ))}
      </g>
      <circle cx="320" cy="300" r="135" fill="#080B0F" fillOpacity=".32" />
      <g className="art-monogram">
        <path
          d="M365 232c-13-14-29-21-49-21-36 0-59 23-59 49 0 59 118 5 118 64 0 26-23 49-59 49-22 0-41-8-55-23"
          stroke="url(#symbol-gold)"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <path
          d="m343 193-70 192m88-181-70 192"
          stroke="url(#symbol-gold)"
          strokeWidth="1.3"
        />
      </g>
      <path
        d="M106 449c53 13 149-10 245-66s164-128 177-178"
        stroke="url(#orbit-gold)"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <path
        d="M109 454c54 12 151-13 248-69s163-130 175-181"
        stroke="#D6B56B"
        strokeWidth=".5"
        strokeOpacity=".5"
      />
      <circle cx="133" cy="436" r="4" fill="#F1DCAC" />
      <circle cx="508" cy="207" r="3" fill="#E8CE92" />
      <g stroke="#D6B56B" strokeWidth="1">
        <path d="M520 92v22m-11-11h22" />
        <path d="M128 169v10m-5-5h10" />
        <path d="M465 491v14m-7-7h14" />
      </g>
      <circle cx="194" cy="94" r="2" fill="#D6B56B" opacity=".55" />
      <circle cx="551" cy="375" r="1.5" fill="#D6B56B" opacity=".7" />
      <g
        fill="#A99B7E"
        fontSize="8"
        letterSpacing="2.3"
        fontFamily="sans-serif"
      >
        <text x="395" y="82">
          PURPOSE IN EVERY STEP
        </text>
        <text x="57" y="537">
          VISION / STRATEGY / GROWTH
        </text>
      </g>
      <path
        d="M61 515h32M77 499v32"
        stroke="#D6B56B"
        strokeOpacity=".3"
        strokeWidth=".6"
      />
    </svg>
  );
}
