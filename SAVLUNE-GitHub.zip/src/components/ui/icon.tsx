import {
  ArrowUpRight,
  BookOpen,
  BriefcaseBusiness,
  ChartNoAxesCombined,
  Compass,
  GraduationCap,
  Handshake,
  Lightbulb,
  MessageCircle,
  Network,
  Scale,
  ShieldCheck,
  Sparkles,
  UserRoundCheck,
  UserRound,
  type LucideProps,
} from "lucide-react";

const icons = {
  ArrowUpRight,
  BookOpen,
  BriefcaseBusiness,
  ChartNoAxesCombined,
  Compass,
  GraduationCap,
  Handshake,
  Lightbulb,
  MessageCircle,
  Network,
  Scale,
  ShieldCheck,
  Sparkles,
  UserRoundCheck,
  UserRound,
};

export function Icon({ name, ...props }: LucideProps & { name: string }) {
  const Component = icons[name as keyof typeof icons] ?? Sparkles;
  return <Component strokeWidth={1.5} aria-hidden="true" {...props} />;
}
