export function BrandMark({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M34 11.5C31.4 8.9 28 7.5 24 7.5c-7.4 0-12 4.7-12 10 0 12 24 1 24 13 0 5.4-4.6 10-12 10-4.6 0-8.4-1.7-11.2-4.6"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path
        d="M29.5 4.5 15 43.5M33 7 18.5 45.5"
        stroke="currentColor"
        strokeWidth=".7"
        opacity=".65"
      />
      <path
        d="M39 12v7m-3.5-3.5h7M8 27v5m-2.5-2.5h5"
        stroke="currentColor"
        strokeWidth="1"
      />
    </svg>
  );
}
