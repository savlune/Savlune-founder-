import { Reveal } from "./reveal";
import type { ReactNode } from "react";

export function SectionHeading({
  number,
  label,
  title,
  children,
  className = "",
}: {
  number: string;
  label: string;
  title: ReactNode;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <Reveal className={`section-heading ${className}`}>
      <p className="section-eyebrow">
        <span>{number}</span>
        <span className="eyebrow-line" />
        {label}
      </p>
      <h2 className="section-title">{title}</h2>
      {children && <p className="section-description">{children}</p>}
    </Reveal>
  );
}
