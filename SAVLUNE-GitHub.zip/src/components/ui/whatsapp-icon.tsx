export function WhatsAppIcon({
  size = 20,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M20.6 11.7a8.6 8.6 0 0 1-12.7 7.5L3 20.5l1.3-4.7a8.6 8.6 0 1 1 16.3-4.1Z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path
        d="m8.3 7.7.8-.1.9 2-.7.8c.7 1.4 1.8 2.4 3.3 3l.8-.9 2 .9v.9c-.2 1-1 1.4-1.9 1.3-3.6-.5-6.3-3.3-6.7-6.4-.1-.7.5-1.4 1.5-1.5Z"
        fill="currentColor"
      />
    </svg>
  );
}
