"use client";
import { useRef } from "react";
import { motion, useInView, useReducedMotion, useScroll, useTransform } from "motion/react";

export function TopicScene({ topic, compact = false }: { topic: "legal" | "finance" | "business" | "commodity" | "currency"; compact?: boolean }) {
  const ref=useRef<HTMLDivElement>(null);
  const visible=useInView(ref,{margin:"80px"});
  const reduce=useReducedMotion();
  const {scrollYProgress}=useScroll({target:ref,offset:["start end","end start"]});
  const turn=useTransform(scrollYProgress,[0,.5,1],[-10,0,10]);
  const lift=useTransform(scrollYProgress,[0,1],[14,-14]);
  const bookOpen=useTransform(scrollYProgress,[0,.28,.72,1],[168,0,0,168]);
  const pageTurn=useTransform(scrollYProgress,[0,.28,.5,.72,1],[0,0,-160,-180,-180]);
  const legal=topic==="legal";
  return <div ref={ref} className={`topic-scene scene-${topic} ${compact?"scene-compact":""} ${visible&&!reduce?"scene-active":""}`} aria-hidden="true">
    {legal && <div className="scroll-book">
      <div className="book-spread">
        <div className="book-leaf book-right"><span/><span/><span/><span/><span/></div>
        <motion.div className="book-leaf book-left" style={{rotateY:reduce?0:bookOpen}}><span/><span/><span/><span/><span/><i>LEX</i></motion.div>
        <motion.div className="book-leaf book-turning" style={{rotateY:reduce?-180:pageTurn}}><span/><span/><span/><span/></motion.div>
        <div className="book-spine"/>
      </div>
    </div>}
    <motion.svg viewBox="0 0 400 250" fill="none" style={reduce?undefined:{y:lift}}>
      <circle cx="200" cy="123" r="96" fill="currentColor" fillOpacity=".035"/>
      <circle className="scene-ring" cx="200" cy="123" r="108" stroke="currentColor" strokeOpacity=".2" strokeDasharray="4 12"/>
      {legal ? <g stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M145 213H255M165 202H235M200 70V200"/>
        <circle cx="200" cy="64" r="10" fill="currentColor" fillOpacity=".15"/>
        <motion.g style={reduce?undefined:{rotate:turn,transformOrigin:"200px 86px"}}>
          <path d="M110 87Q200 67 290 87"/>
          <path d="M125 86 99 150H151ZM275 86 249 150H301" strokeOpacity=".65"/>
          <path d="M94 150Q125 189 156 150ZM244 150Q275 189 306 150Z" fill="currentColor" fillOpacity=".2"/>
        </motion.g>

      </g> : topic==="business" ? <g stroke="currentColor" strokeWidth="2" strokeLinejoin="round">
        {[0,1,2].map(i=><g className={`scene-building scene-building-${i}`} key={i}><path d={`M${105+i*65} 207V${110-i*27}l45-14v${111+i*27}Z`} fill="currentColor" fillOpacity=".1"/>{[0,1,2].map(j=><path key={j} d={`M${116+i*65} ${120-i*27+j*22}h20`} strokeOpacity=".5"/>)}</g>)}
        <path d="M75 212H325" strokeOpacity=".5"/><g className="scene-person"><circle cx="305" cy="156" r="10" fill="currentColor" fillOpacity=".2"/><path d="M291 204v-24q14-18 28 0v24M305 180v28"/></g>
      </g> : topic==="commodity" ? <g stroke="currentColor" strokeWidth="2" strokeLinejoin="round">
        <g className="scene-bars"><path d="M80 195 100 153H178L198 195ZM186 195 207 153H285L305 195ZM134 148 154 106H232L252 148Z" fill="currentColor" fillOpacity=".17"/><path d="M100 153 113 180H185M207 153 220 180H292M154 106 168 134H245" strokeOpacity=".5"/></g><text x="193" y="125" fill="currentColor" stroke="none" textAnchor="middle" fontSize="13">Au</text>
      </g> : topic==="currency" ? <g stroke="currentColor" strokeWidth="2">
        <g className="scene-coin"><circle cx="150" cy="123" r="53" fill="currentColor" fillOpacity=".1"/><circle cx="150" cy="123" r="43" strokeOpacity=".4"/><text x="150" y="141" textAnchor="middle" fill="currentColor" stroke="none" fontSize="48">$</text></g>
        <g className="scene-coin second"><circle cx="256" cy="157" r="45" fill="currentColor" fillOpacity=".08"/><text x="256" y="170" textAnchor="middle" fill="currentColor" stroke="none" fontSize="30">Rp</text></g><path className="scene-route" d="M154 52Q230 20 288 88m-18-5 18 5-2-19M250 218Q178 241 119 204m20 0-20 0 5 18" strokeLinecap="round"/>
      </g> : <g stroke="currentColor" strokeWidth="2" strokeLinecap="round">
        <path d="M65 60V205H335M65 155H335M65 105H335" strokeOpacity=".15"/>
        {[70,105,90,145,175,155].map((h,i)=><rect className={`scene-chart-bar scene-building-${i%3}`} key={i} x={90+i*38} y={205-h} width="20" height={h} rx="3" fill="currentColor" fillOpacity=".14" stroke="none"/>)}
        <path className="scene-chart-line" d="M80 171 122 145 160 161 198 100 236 114 277 66 323 45" strokeWidth="3"/><circle className="scene-dot" cx="323" cy="45" r="5" fill="currentColor"/>
      </g>}
      <g className="scene-sparkles" fill="currentColor"><circle cx="57" cy="85" r="2"/><circle cx="338" cy="71" r="3"/><circle cx="341" cy="190" r="2"/></g>
    </motion.svg>
  </div>;
}
