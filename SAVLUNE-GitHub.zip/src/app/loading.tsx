import { BrandMark } from "@/components/ui/brand-mark";
export default function Loading() {
  return (
    <div
      className="loading-screen"
      role="status"
      aria-label="Memuat profil SAVLUNE"
    >
      <BrandMark className="loading-mark" />
      <span>SAVLUNE</span>
      <div className="loading-line" />
      <span className="sr-only">Memuat profil…</span>
    </div>
  );
}
