import { GlobalInsights } from "@/components/sections/global-insights";
import { Sponsors, Community } from "@/components/sections/community";
import { Navbar } from "@/components/navbar";
import { FloatingActions } from "@/components/floating-actions";
import { Hero } from "@/components/sections/hero";
import { About } from "@/components/sections/about";
import { Focus } from "@/components/sections/focus";
import { Founder } from "@/components/sections/founder";
import { Trust } from "@/components/sections/trust";
import { Services } from "@/components/sections/services";
import { WhySavlune } from "@/components/sections/why-savlune";
import { Contact } from "@/components/sections/contact";
import { Footer } from "@/components/sections/footer";
import { founder } from "@/data/founder";
import { contact } from "@/data/contact";
import { siteUrl } from "@/lib/site";

export default function Home() {
  const person = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: founder.name,
    image: founder.photo ? `${siteUrl}${founder.photo}` : undefined,
    jobTitle: founder.role,
    description: founder.description,
    url: siteUrl,
    email: contact.email,
    address: {
      "@type": "PostalAddress",
      addressLocality: "Samarinda",
      addressRegion: "Kalimantan Timur",
      addressCountry: "ID",
    },
    knowsAbout: ["Kewirausahaan", "Literasi keuangan", "Literasi hukum dasar"],
  };
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(person).replace(/</g, "\\u003c"),
        }}
      />
      <Navbar />
      <main id="main">
        <Hero />
        <Sponsors />
        <GlobalInsights />
        <About />
        <Focus />
        <Founder />
        <Trust />
        <Services />
        <WhySavlune />
        <Community />
        <Contact />
      </main>
      <Footer />
      <FloatingActions />
    </>
  );
}
