import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { brand } from "@/data/brand";
import { siteUrl } from "@/lib/site";

const manrope = localFont({
  src: [
    { path: "../../public/fonts/manrope-regular.woff2", weight: "400" },
    { path: "../../public/fonts/manrope-semibold.woff2", weight: "600" },
  ],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "SAVLUNE | Situs Resmi Muhammad Luthfi Yannur",
  description:
    "Situs resmi pribadi Muhammad Luthfi Yannur, Founder SAVLUNE dan mahasiswa hukum di Samarinda. Ruang diskusi bisnis, wawasan keuangan, literasi hukum dasar, dan kolaborasi.",
  applicationName: brand.name,
  keywords: [
    "SAVLUNE",
    "Muhammad Luthfi Yannur",
    "Savlune Founder",
    "Samarinda",
    "wirausaha muda",
    "literasi hukum",
    "bisnis",
    "market insight",
  ],
  authors: [{ name: "Muhammad Luthfi Yannur" }],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "id_ID",
    url: "/",
    siteName: brand.name,
    title: "SAVLUNE — Vision. Strategy. Growth.",
    description:
      "Situs resmi pribadi Muhammad Luthfi Yannur. Bisnis, wawasan keuangan, dan literasi hukum dalam satu langkah yang lebih terarah.",
    images: [
      {
        url: "/Savlune-founder-/images/og-cover.png",
        width: 1200,
        height: 630,
        alt: "SAVLUNE — Vision. Strategy. Growth. | Muhammad Luthfi Yannur",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "SAVLUNE — Vision. Strategy. Growth.",
    description: "Situs resmi pribadi Muhammad Luthfi Yannur, Founder SAVLUNE.",
    images: ["/Savlune-founder-/images/og-cover.png"],
  },
  icons: { icon: "/Savlune-founder-/icon.svg", apple: "/Savlune-founder-/images/apple-icon.png" },
  robots: { index: true, follow: true },
  category: "business",
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#080B0F",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id" className={manrope.variable}>
      <body>
        <a className="skip-link" href="#main">
          Langsung ke konten utama
        </a>
        {children}
      </body>
    </html>
  );
}
