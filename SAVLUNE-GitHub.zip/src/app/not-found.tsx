import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { BrandMark } from "@/components/ui/brand-mark";
export default function NotFound() {
  return (
    <main className="not-found">
      <BrandMark className="not-found-mark" />
      <p className="section-eyebrow">404 / A DIFFERENT DIRECTION</p>
      <h1>
        Temukan kembali
        <br />
        <em>arah Anda.</em>
      </h1>
      <p>Halaman ini belum tersedia. Mari kembali mengenal SAVLUNE.</p>
      <Link href="/" className="button button-gold">
        Kembali ke Beranda
        <ArrowUpRight size={18} />
      </Link>
    </main>
  );
}
