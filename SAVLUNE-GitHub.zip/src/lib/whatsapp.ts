import { contact } from "@/data/contact";

export type ContactMessageInput = {
  name: string;
  purpose: string;
  message: string;
};

/** Encode the entire message so punctuation, emoji, and newlines stay intact. */
export function getWhatsAppUrl(message?: string): string {
  const text = message?.trim() || contact.defaultMessage;
  return `https://wa.me/${contact.whatsappNumber}?text=${encodeURIComponent(text)}`;
}

/** Build the message locally; contact details are never sent to an app server. */
export function buildContactMessage({
  name,
  purpose,
  message,
}: ContactMessageInput): string {
  return `Halo, nama saya ${name.trim()}. Saya ingin ${purpose.trim()}. Pesan saya: ${message.trim()}`;
}
