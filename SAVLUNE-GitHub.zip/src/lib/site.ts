/** Set NEXT_PUBLIC_SITE_URL to your final production origin when deploying. */
export const siteUrl = (
  process.env.NEXT_PUBLIC_SITE_URL ||
  "https://savlune.github.io/Savlune-founder-"
).replace(/\/$/, "");
