/** Keep the WhatsApp destination here so every contact link stays in sync. */
export const contact = {
  whatsappNumber: "6282156067048",
  whatsappDisplay: "0821-5606-7048",
  email: "savlunesamarinda@gmail.com",
  location: "Samarinda, Kalimantan Timur",
  defaultMessage: "Halo, saya ingin bertanya tentang SAVLUNE.",
} as const;
