export const services = [
  {
    id: "bisnis",
    number: "01",
    title: "Diskusi Bisnis Dasar",
    description: "Dari ide awal menuju langkah usaha yang lebih terarah.",
    icon: "Lightbulb",
    topics: [
      "Ide usaha & pengembangan usaha kecil",
      "Branding awal & pemasaran dasar",
      "Arah pengembangan bisnis",
    ],
    whatsappMessage: "Halo, saya ingin diskusi tentang bisnis dasar.",
  },
  {
    id: "market",
    number: "02",
    title: "Diskusi Market & Keuangan Edukatif",
    description: "Memperluas pemahaman keuangan melalui diskusi edukatif.",
    icon: "ChartNoAxesCombined",
    topics: [
      "Pemahaman dasar market & insight ekonomi",
      "Pembelajaran mindset keuangan",
      "Diskusi umum saham, forex, komoditas & aset digital",
    ],
    whatsappMessage: "Halo, saya ingin diskusi tentang market dan keuangan.",
  },
  {
    id: "hukum",
    number: "03",
    title: "Diskusi Literasi Hukum Dasar",
    description: "Mengenal hukum dasar dalam keseharian dan aktivitas usaha.",
    icon: "Scale",
    topics: [
      "Wawasan hukum dasar & dokumen sederhana",
      "Kesadaran hukum dalam aktivitas bisnis",
      "Diskusi awal hukum bisnis untuk edukasi dasar",
    ],
    note: "Edukasi dasar, bukan pendampingan advokat resmi.",
    whatsappMessage: "Halo, saya ingin bertanya tentang literasi hukum dasar.",
  },
  {
    id: "kolaborasi",
    number: "04",
    title: "Kolaborasi & Partnership",
    description: "Membuka percakapan untuk peluang dan pertumbuhan bersama.",
    icon: "Handshake",
    topics: [
      "Kerja sama brand & diskusi peluang",
      "Relasi profesional",
      "Project collaboration",
    ],
    whatsappMessage: "Halo, saya tertarik berkolaborasi dengan SAVLUNE.",
  },
  {
    id: "personal-brand",
    number: "05",
    title: "Profil & Konsultasi Personal Brand",
    description:
      "Mendiskusikan cara menampilkan identitas diri secara konsisten.",
    icon: "UserRound",
    topics: [
      "Membangun image profesional",
      "Portofolio pribadi",
      "Positioning diri",
    ],
    whatsappMessage:
      "Halo, saya ingin diskusi tentang profil dan personal brand.",
  },
] as const;

export type Service = (typeof services)[number];
