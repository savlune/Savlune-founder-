export const founder = {
  name: "Muhammad Luthfi Yannur",
  role: "Founder SAVLUNE",
  initials: "MLY",
  photo: "/Savlune-founder-/images/founder.webp",
  subtitle: "Mahasiswa Hukum | Wirausaha Muda | Siap Berkontribusi",
  description:
    "Muhammad Luthfi Yannur adalah mahasiswa hukum yang memiliki ketertarikan besar terhadap dunia bisnis, keuangan, dan pengembangan diri. Pengalamannya di bidang sales, pelayanan pelanggan, dan pengelolaan usaha menjadi bagian dari proses membangun SAVLUNE. Dengan semangat belajar dan membangun, ia mengembangkan identitas yang mencerminkan visi jangka panjang, integritas, dan keinginan untuk terus bertumbuh.",
  facts: [
    "Berdomisili di Samarinda, Kalimantan Timur",
    "Mahasiswa S1 Hukum — Universitas 17 Agustus 1945 Samarinda",
    "Memiliki minat pada bisnis, keuangan, dan hukum bisnis",
    "Berpengalaman dalam sales, pelayanan pelanggan, dan operasional usaha",
    "Terbuka untuk kolaborasi dan diskusi yang bermanfaat",
  ],
  roles: ["Mahasiswa Hukum", "Founder SAVLUNE", "Wirausaha Muda"],
} as const;
