/** Selected experience and training transcribed from the founder's supplied CV and certificates. */
export const experience = [
  {
    id: "savlune",
    role: "Owner / Business Operator",
    organization: "SAVLUNE",
    period: "Sekarang",
    location: "Samarinda",
    description:
      "Mengembangkan dan mengelola kegiatan usaha di bidang F&B, fashion, dan penjualan online.",
    highlights: [
      "Pembelian, pengelolaan stok, harga, promosi, dan pelayanan pelanggan.",
      "Materi pemasaran digital serta pencatatan penjualan dan pengeluaran.",
    ],
  },
  {
    id: "sales-consultant",
    role: "Sales Consultant",
    organization: "Mitsubishi · PT Mahakam Berlian Samjaya",
    period: "2026",
    location: "Samarinda, Kalimantan Timur",
    description:
      "Pengalaman dalam komunikasi produk, pengelolaan prospek, dan koordinasi proses penjualan otomotif.",
    highlights: [
      "Prospecting dan follow-up melalui WhatsApp, media sosial, dan referral.",
      "Penjelasan produk, promo, simulasi pembiayaan, serta tindak lanjut pelanggan.",
    ],
  },
] as const;

export const education = {
  program: "S1 Hukum",
  institution: "Universitas 17 Agustus 1945 Samarinda",
  period: "2025 — Sekarang",
  status: "Mahasiswa aktif",
} as const;

export const competencies = [
  "Sales & Negosiasi",
  "Customer Service",
  "Administrasi & Data",
  "Stok & Inventory",
  "Laporan Operasional",
  "Digital Marketing",
  "Microsoft Office",
  "Google Workspace",
  "Public Speaking",
  "Riset Hukum Dasar",
] as const;

/** Educational discussion topics; these are not formal qualifications or performance claims. */
export const learningAreas = [
  {
    id: "legal-learning",
    title: "Literasi Hukum Dasar",
    description:
      "Memperluas pemahaman mengenai aturan, hubungan hukum, dan proses penyelesaian persoalan melalui pembelajaran hukum dasar.",
    icon: "Scale",
    topics: ["Hukum perdata", "Hukum pidana", "Hukum acara perdata"],
    note: "Ruang diskusi edukatif; bukan layanan advokat atau nasihat hukum profesional.",
  },
  {
    id: "market-learning",
    title: "Market & Evaluasi",
    description:
      "Mendiskusikan cara membaca catatan hasil, memahami konteks periode, serta mengenali risiko dalam aktivitas pasar.",
    icon: "ChartNoAxesCombined",
    topics: [
      "Membaca catatan PNL",
      "Hasil terealisasi & belum terealisasi",
      "Evaluasi periode & kesadaran risiko",
    ],
    note: "Pembelajaran pasar; bukan rekomendasi investasi atau jaminan hasil.",
  },
] as const;

// These documents show course participation; they do not establish a professional license.
export const certificates = [
  {
    id: "samarinda-training-center",
    title: "Public Speaking / Customer Service",
    issuer: "Samarinda Training Center",
    date: "25 Juli 2024",
    period: "22–25 Juli 2024",
    number: "2024/PSC-0725/SMR/00123",
    image: "/Savlune-founder-/images/certificates/public-speaking-samarinda.webp",
    width: 1280,
    height: 904,
    alt: "Sertifikat peserta Public Speaking / Customer Service atas nama Muhammad Luthfi Yannur, Samarinda Training Center, 25 Juli 2024.",
  },
  {
    id: "cendekia-inspira",
    title: "Public Speaking & Customer Service",
    issuer: "Cendekia Inspira Training Center",
    date: "25 Juli 2024",
    period: null,
    number: "24/CSPC/VII/2024/1587",
    image: "/Savlune-founder-/images/certificates/public-speaking-cendekia.webp",
    width: 1280,
    height: 904,
    alt: "Sertifikat peserta Public Speaking & Customer Service atas nama Muhammad Luthfi Yannur, Cendekia Inspira Training Center, 25 Juli 2024.",
  },
] as const;
