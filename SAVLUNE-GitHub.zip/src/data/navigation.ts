export const navigation = [
  { label: "Beranda", href: "#beranda" },
  { label: "Insight", href: "#insight" },
  { label: "Sponsor", href: "#sponsor" },
  { label: "Founder", href: "#founder" },
  { label: "Cerita", href: "#cerita" },
  { label: "Kontak", href: "#kontak" },
] as const;

export const footerNavigation = navigation.filter(
  (item) => item.href !== "#beranda",
);
