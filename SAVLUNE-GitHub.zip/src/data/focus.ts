export const focusAreas = [
  {
    id: "business",
    number: "01",
    label: "BUSINESS",
    title: "Usaha & Bisnis",
    description:
      "Ide usaha, pemasaran, dan kerja sama.",
    topics: ["Pengembangan usaha", "Branding & pemasaran", "Kolaborasi"],
    icon: "BriefcaseBusiness",
    disclaimer: null,
  },
  {
    id: "finance",
    number: "02",
    label: "FINANCE",
    title: "Keuangan & Pasar",
    description:
      "Membaca ekonomi, mata uang, komoditas, dan perusahaan.",
    topics: ["Literasi keuangan", "Wawasan ekonomi", "Market insight"],
    icon: "ChartNoAxesCombined",
    disclaimer:
      "Konten keuangan bersifat edukatif dan bukan ajakan investasi atau jaminan profit.",
  },
  {
    id: "legal",
    number: "03",
    label: "LEGAL INSIGHT",
    title: "Hukum & Usaha",
    description:
      "Belajar aturan dan dokumen yang berkaitan dengan usaha.",
    topics: ["Literasi hukum dasar", "Dokumen bisnis", "Kesadaran hukum"],
    icon: "Scale",
    disclaimer:
      "Informasi hukum di website ini bersifat edukatif dan bukan pengganti nasihat hukum profesional.",
  },
] as const;
