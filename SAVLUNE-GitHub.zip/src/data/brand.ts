export const brand = {
  name: "SAVLUNE",
  profileName: "Savlune Founder",
  tagline: "Vision. Strategy. Growth.",
  heroDescription:
    "Membangun identitas yang memadukan kewirausahaan, wawasan keuangan, dan literasi hukum dalam satu langkah yang lebih terarah.",
  personalIntroduction:
    "Situs resmi pribadi Muhammad Luthfi Yannur — Founder SAVLUNE, mahasiswa hukum, dan wirausaha muda yang berfokus pada pertumbuhan, pembelajaran, dan kontribusi nyata.",
  about:
    "SAVLUNE adalah identitas bisnis dan personal brand yang dibangun untuk merepresentasikan visi, strategi, dan pertumbuhan. Berangkat dari minat pada dunia usaha, pasar keuangan, dan ilmu hukum, SAVLUNE hadir sebagai ruang pengembangan ide, wawasan, dan kolaborasi.",
  disclaimer:
    "Informasi pada website ini bersifat informatif dan edukatif. Konten keuangan maupun hukum bukan pengganti nasihat profesional resmi.",
  copyright: "© 2026 SAVLUNE. All Rights Reserved.",
} as const;

export const coreValues = [
  {
    number: "01",
    title: "Integritas",
    description:
      "Membangun kepercayaan melalui identitas yang jelas, komunikasi terbuka, dan tanggung jawab.",
    icon: "ShieldCheck",
  },
  {
    number: "02",
    title: "Pembelajaran Berkelanjutan",
    description:
      "Terus memperluas wawasan, mendengar perspektif baru, dan belajar dari setiap proses.",
    icon: "BookOpen",
  },
  {
    number: "03",
    title: "Pertumbuhan Strategis",
    description:
      "Melangkah dengan visi yang terarah, pemikiran yang matang, dan semangat untuk berkembang.",
    icon: "TrendingUp",
  },
] as const;
