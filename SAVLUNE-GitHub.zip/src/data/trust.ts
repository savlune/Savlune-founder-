export const trustBackgrounds = [
  {
    title: "Background Akademik",
    description:
      "Mahasiswa aktif S1 Hukum di Universitas 17 Agustus 1945 Samarinda sejak 2025, dengan minat pada hukum, regulasi, dan kesadaran hukum dalam aktivitas usaha.",
    icon: "GraduationCap",
  },
  {
    title: "Jiwa Wirausaha",
    description:
      "Mengelola SAVLUNE dalam kegiatan usaha F&B, fashion, dan penjualan online, mencakup promosi, pelayanan pelanggan, pengelolaan stok, dan pencatatan operasional.",
    icon: "BriefcaseBusiness",
  },
  {
    title: "Minat Strategis",
    description:
      "Aktif mempelajari perkembangan pasar, wawasan ekonomi, literasi keuangan, dan pendekatan strategis untuk pengambilan keputusan.",
    icon: "Compass",
  },
  {
    title: "Komitmen Pribadi",
    description:
      "Menjunjung integritas, pembelajaran berkelanjutan, komunikasi yang baik, dan tanggung jawab dalam setiap langkah pengembangan diri maupun bisnis.",
    icon: "ShieldCheck",
  },
] as const;

export const founderBadges = [
  "Mahasiswa Hukum",
  "Founder SAVLUNE",
  "Wirausaha Muda",
  "Fokus Bisnis & Market Insight",
  "Literasi Hukum Dasar",
  "Siap Berkolaborasi",
] as const;

export const trustReasons = [
  "Identitas jelas",
  "Kontak langsung aktif",
  "Profil personal terbuka",
  "Pendekatan profesional",
  "Fokus pada pembelajaran dan kontribusi",
  "Komunikasi mudah melalui WhatsApp",
] as const;

export const whySavlune = [
  {
    title: "Profil founder jelas",
    description: "Kenali identitas, latar belakang, dan bidang minat founder.",
    icon: "UserRoundCheck",
  },
  {
    title: "Terhubung langsung",
    description: "Mulai percakapan dengan founder melalui WhatsApp.",
    icon: "MessageCircle",
  },
  {
    title: "Pendekatan profesional",
    description: "Komunikasi yang terbuka, jelas, dan saling menghargai.",
    icon: "Handshake",
  },
  {
    title: "Pembelajaran & solusi",
    description: "Ruang bertukar perspektif dan mencari langkah yang relevan.",
    icon: "Lightbulb",
  },
  {
    title: "Wawasan yang terhubung",
    description: "Memadukan minat pada bisnis, keuangan, dan literasi hukum.",
    icon: "Network",
  },
  {
    title: "Identitas yang konsisten",
    description:
      "Profil modern dan informasi yang disampaikan secara transparan.",
    icon: "Sparkles",
  },
] as const;
